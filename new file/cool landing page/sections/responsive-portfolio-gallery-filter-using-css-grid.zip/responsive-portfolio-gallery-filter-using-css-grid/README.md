# Responsive Portfolio Gallery Filter Using CSS Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkmquitasol/pen/JxrKxX](https://codepen.io/jkmquitasol/pen/JxrKxX).

