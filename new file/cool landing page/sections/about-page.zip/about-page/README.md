# About page

A Pen created on CodePen.io. Original URL: [https://codepen.io/ruben-vardanyan/pen/LYYPwjm](https://codepen.io/ruben-vardanyan/pen/LYYPwjm).

About page