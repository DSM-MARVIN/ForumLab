# Technologies

A Pen created on CodePen.io. Original URL: [https://codepen.io/cassiocardoso/pen/oXbvMj](https://codepen.io/cassiocardoso/pen/oXbvMj).

Technologies I like to use for projects. Also playing around with flexbox.