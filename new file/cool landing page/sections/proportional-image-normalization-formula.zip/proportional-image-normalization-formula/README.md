# Proportional Image Normalization Formula

A Pen created on CodePen.io. Original URL: [https://codepen.io/danpaquette/pen/jXpbQK](https://codepen.io/danpaquette/pen/jXpbQK).

I often have a series of logos or icons of varying sizes and proportions, and I want to line them up all next to each other so they look nice. This is a common design element on websites that feature customer logos, publications that mention them, or associations they belong to.

Making them all the same width or same height makes some of them gigantic while others are barely legible. This normalizes the size each image taking into account the images aspect ratio.