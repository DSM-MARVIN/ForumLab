# Animated title using JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/tahaharnoune/pen/WNzBxPp](https://codepen.io/tahaharnoune/pen/WNzBxPp).

in this pen i created a main website portfolio with Html /Css / Js in one html file, we have here different titles changed in function of time with simple color effect and nice background illustration image  to make it look professional