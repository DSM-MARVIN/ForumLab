# Responsive portfolio gallery

A Pen created on CodePen.io. Original URL: [https://codepen.io/isaacsgraphic/pen/LVEBwM](https://codepen.io/isaacsgraphic/pen/LVEBwM).

This is a responsive grid for a porfolio gallery, built using only HTML and CSS. It's based on the Squarespace "flatiron" template. Images scale up, the boxes fade darker, and a caption zooms in.