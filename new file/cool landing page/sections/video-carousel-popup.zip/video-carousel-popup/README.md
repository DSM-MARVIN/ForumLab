# Video Carousel Popup

A Pen created on CodePen.io. Original URL: [https://codepen.io/codersdesign/pen/ZEobNOQ](https://codepen.io/codersdesign/pen/ZEobNOQ).

Lightweight image carousel with modal popup video player. Accepts images, videos, and external links. Easy to use and easy to implement. Enjoy!