# Clients - Logos (blur)

A Pen created on CodePen.io. Original URL: [https://codepen.io/jlantunez/pen/NLwGEq](https://codepen.io/jlantunez/pen/NLwGEq).

