# Easybank landing page_Frontend Mentor

A Pen created on CodePen.io. Original URL: [https://codepen.io/FedLover/pen/ExoNxyj](https://codepen.io/FedLover/pen/ExoNxyj).

Intermediate level Frontend Mentor challenge.
The challenge is to build out a landing page and get it looking as close to the design as possible.

Challenge solution on Frontend Mentor: 
https://www.frontendmentor.io/solutions/easybank-landing-page-RY7S7zssL

Live site on Github: https://mohamedaridah.github.io/frontendmentor_easybank-landing-page/