$("#myCarousel").carousel({
  interval: false
});