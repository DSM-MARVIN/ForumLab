# landing page Game Agency

A Pen created on CodePen.io. Original URL: [https://codepen.io/Ali-Majed/pen/dyRZqxd](https://codepen.io/Ali-Majed/pen/dyRZqxd).

This project design by https://www.figma.com/@irmamagden
I hope you like it.