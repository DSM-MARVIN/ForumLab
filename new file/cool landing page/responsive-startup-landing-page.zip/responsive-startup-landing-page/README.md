# Responsive Startup Landing Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/saarthak-slathia/pen/BaZpZPo](https://codepen.io/saarthak-slathia/pen/BaZpZPo).

Inspiration from 👉🏻 https://dribbble.com/shots/16396714-Most-Exciting-Startups

Scrollbar from 👉🏻 https://codepen.io/GhostRider/pen/GHaFw?editors=0100