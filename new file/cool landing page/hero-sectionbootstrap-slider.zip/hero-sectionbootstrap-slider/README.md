# Hero Section - Bootstrap slider

A Pen created on CodePen.io. Original URL: [https://codepen.io/ReechStudio/pen/aXxOVd](https://codepen.io/ReechStudio/pen/aXxOVd).

Responsive Hero Section using Bootstrap & Bootstrap fade slider