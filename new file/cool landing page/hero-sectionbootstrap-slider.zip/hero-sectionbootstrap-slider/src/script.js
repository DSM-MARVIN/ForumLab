$('.carousel').carousel({
  interval: 9000
})