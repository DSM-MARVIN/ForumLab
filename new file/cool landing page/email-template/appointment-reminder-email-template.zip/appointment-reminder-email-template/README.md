# Appointment Reminder Email Template

A Pen created on CodePen.io. Original URL: [https://codepen.io/rKalways/pen/MWWQjvm](https://codepen.io/rKalways/pen/MWWQjvm).

