# Simple Landing Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/Perfec2Tech/pen/XWEzpqb](https://codepen.io/Perfec2Tech/pen/XWEzpqb).

