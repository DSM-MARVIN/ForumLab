# URL shortening API landing page_Frontend Mentor

A Pen created on CodePen.io. Original URL: [https://codepen.io/FedLover/pen/NWXPeae](https://codepen.io/FedLover/pen/NWXPeae).

Intermediate level Frontend Mentor challenge.
The challenge is integrated with the shrtcode API to create shortened URLs. With the ability to copy the generated link. and the generated URLs that user create will be exist even after refreshing the browser.

Challenge solution on Frontend Mentor: 
https://www.frontendmentor.io/solutions/url-shortening-api-landing-page-using-sass-and-javascript-wq4AVIAm9

Live site on Github: https://mohamedaridah.github.io/frontendmentor_url-shortening-api/