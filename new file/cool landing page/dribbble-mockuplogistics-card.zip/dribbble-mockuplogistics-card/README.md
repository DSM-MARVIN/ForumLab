# Dribbble Mockup - Logistics Card

A Pen created on CodePen.io. Original URL: [https://codepen.io/mirandalwashburn/pen/vYLwjXw](https://codepen.io/mirandalwashburn/pen/vYLwjXw).

