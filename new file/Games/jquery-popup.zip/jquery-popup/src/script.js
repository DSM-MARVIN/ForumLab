$(".buttons a").on("click", function() {
  $(".overlay").addClass("is-on");
});

$("#close").on("click", function() {
  $(".overlay").removeClass("is-on");
});
