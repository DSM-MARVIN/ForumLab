$(function() {
  'use strict';

  // page transition to top
  $('.totop').click(function() {
    $('body,html').stop().animate({scrollTop: 0}, 500); 
  });

  var headerHeight = $('header').outerHeight();

  // page transition
  // $('a[href^="#"]').click(function() {
  //   var href = $(this).attr("href");
  //   var target = $(href);
  //   var position = target.offset().top - headerHeight;
  //   $('body,html').stop().animate({scrollTop: position}, 500);   
  //   return false;
  // });
  
  // header menu put underline
  $('.h_pc .h_item a').click(function() {
    $('.h_pc .h_item').children('a').removeClass('active');
    $(this).addClass('active');
  });
  
  // sp navigation
  $('.navbar_toggle,.pc_nav_overlay').on('click', function () {
    $('.navbar_toggle').toggleClass('open');
    $('.navbar_toggle_icon').toggleClass('open');
    $('.h_sp').toggleClass('open');
    $('.pc_nav_overlay').toggleClass('open');
  });
  
  // delete style while resize
  $(window).resize(function() {
    $('.navbar_toggle').removeClass('open');
    $('.navbar_toggle_icon').removeClass('open');
    $('.h_sp').removeClass('open');
    $('.pc_nav_overlay').removeClass('open');
  });

  // slick definition
  $('.slider').slick({
    autoplay: true,
    autoplaySpeed: 3000,
    slidesToShow: 2,
    dots: true,
    arrows: false,
    responsive:[
      {
        breakpoint: 660,
        settings:{
          slidesToShow: 1,
        }
      },
    ]
  });
  
  // accordion
  $('.faq-item').click(function() {
    var $answer = $(this).find('.answer');
    if($answer.hasClass('open')) {
      $answer.removeClass('open');
      $answer.slideUp();
      $(this).find('span:nth-of-type(2)').css('display', 'block');
    } else {
      $answer.addClass('open');
      $answer.slideDown();
      $(this).find('span:nth-of-type(2)').css('display', 'none');
    }
  });

  // floating item
  jQuery(window).on("scroll", function($) {
    if (jQuery(this).scrollTop() > 500) {
      jQuery('.totop').show();
      jQuery('header').addClass('header_scroll');
    } else {
      jQuery('.totop').hide();
      jQuery('header').removeClass('header_scroll');

    }
  });
});