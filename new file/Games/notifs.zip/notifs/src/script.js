const sleepTime = 900;
const messages = {
  0: {
    msg: "Hi 👋",
    action: false,
    font: 36
  },
  1: {
    msg: "How are you today? 🌈",
    action: false,
    font: 36
  },
  2: {
    msg: "I am your new personal assistant 👍",
    action: false,
    font: 24
  },
  3: {
    msg: "Now a brief recap of your day 📖",
    action: false,
    font: 24
  },
  4: {
    msg: "Remember to go to the gym at 9:00 💪",
    action: true,
    font: 24
  },
  5: {
    msg: "let's do it!! 🔝",
    action: false,
    font: 36
  },
  6: {
    msg: "Remember the meeting with Sarah at 10:00 🤦",
    action: true,
    font: 24
  },
  7: {
    msg: "you're doing great!! 🔝",
    action: false,
    font: 24
  },
  8: {
    msg: "🙌 Project deadline at 17:00 🙌",
    action: true,
    font: 24
  },
  9: {
    msg: "You are a champion! 😎",
    action: false,
    font: 24
  },
  10: {
    msg:
      'Checkout Lucagez profile🚀<br>👉 <a href="https://codepen.io/lucagez">Click Here</a>',
    action: true,
    font: 24
  }
};

const sleep = milliseconds => {
  return new Promise(resolve => setTimeout(resolve, milliseconds));
};

function action(direction, container, notif, actionBlock) {
  move(container, direction);
  sleep(sleepTime * 0.7).then(() => {
    container.removeChild(notif);
    container.removeChild(actionBlock);
  });
  return;
}

function move(element, direction) {
  const moveObj = {
    down: [0, 250],
    right: [400, 250],
    up: [0, -300]
  };

  element.style.transform = `translate(${moveObj[direction][0]}px, ${
    moveObj[direction][1]
  }px)`;
  return;
}

function setup(info, index, container, content, notif, actionBlock) {
  notif.classList.add("notif", "center");
  content.classList.add("content");
  actionBlock.classList.add("action-block", "center");
  content.style.fontSize = `${info[index].font}px`;
  content.innerHTML = `<span>${info[index].msg}</span>`;
  actionBlock.innerHTML =
    '<div class="snooze" ><span>snooze 😴</span></div><div class="tick" >✔</div>';
  notif.appendChild(content);
  console.log(notif);
  return;
}

function render(info, index) {
  const notif = document.createElement("div");
  const content = document.createElement("div");
  const actionBlock = document.createElement("div");
  const container = document.querySelector(".container");

  setup(info, index, container, content, notif, actionBlock);

  if (info[index].action) {
    container.appendChild(notif);
    container.appendChild(actionBlock);

    move(container, "down");
    document.querySelector(".snooze").addEventListener("click", () => {
      action("up", container, notif, actionBlock);
      sleep(sleepTime).then(() => render(info, index + 1));
    });

    document.querySelector(".tick").addEventListener("click", () => {
      action("right", container, notif, actionBlock);
      sleep(sleepTime).then(() => render(info, index + 1));
    });
  } else {
    container.appendChild(notif);
    move(container, "down");
    sleep(sleepTime * 2)
      .then(() => move(container, "up"))
      .then(() => {
        sleep(sleepTime).then(() => {
          container.removeChild(notif);
          render(info, index + 1);
        });
      });
  }
}

render(messages, 0);
