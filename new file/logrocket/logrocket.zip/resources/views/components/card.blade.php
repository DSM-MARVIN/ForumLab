<div {{$attributes->merge(['class' => 'border p-6'])}}>
  {{$slot}}
</div>