# Responsive Analytics Dashboard UI with Tailwind

A Pen created on CodePen.io. Original URL: [https://codepen.io/aisyahnrlh/pen/eYMmdaO](https://codepen.io/aisyahnrlh/pen/eYMmdaO).

Designed by AR Shakir https://dribbble.com/shots/17473449-Analytics-Dashboard-UI-Concept