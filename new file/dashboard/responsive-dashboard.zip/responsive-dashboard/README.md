# Responsive Dashboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/kira-code/pen/LYQmPvb](https://codepen.io/kira-code/pen/LYQmPvb).

Create Simple Dashboard Using HTML and CSS.