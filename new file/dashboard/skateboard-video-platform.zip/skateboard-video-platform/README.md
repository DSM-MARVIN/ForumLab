# Skateboard Video Platform

A Pen created on CodePen.io. Original URL: [https://codepen.io/RezaMohammadian/pen/jOpEwza](https://codepen.io/RezaMohammadian/pen/jOpEwza).

Inspired by Dwinawan 
https://dribbble.com/shots/14958858--Exploration-Skateboard-Video-Platform/attachments/6676841?mode=media

&
Aysenur
https://codepen.io/TurkAysenur/pen/LYRKpWe

* My First Pen  ; )